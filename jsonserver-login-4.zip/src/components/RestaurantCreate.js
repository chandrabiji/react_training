import React, { Component } from 'react'

export class RestaurantCreate extends Component {
  render() {
    return (
      <div>
        <h1>Restaurant Create</h1>
      </div>
    )
  }
}

export default RestaurantCreate
