import React, { Component } from 'react'

export class RestauranstList extends Component {
  constructor(){
    super();
    this.state = {
      list:null
    }
  }
  componentDidMount(){
    fetch("http://localhost:3000/restaurant").then((response)=>{
      response.json().then((result)=>{
        this.setState({list:result})
      })
    })
  }
  render() {

    return (
      <div>
        <h1>Restauranst List</h1>
        {
            this.state.list?
            <div>
             {
               this.state.list.map((item,i)=>
                 <div className="list-wrapper">
                    <span>{item.id}</span>
                   <span>{item.name}</span>
                   <span>{item.email}</span>
                   <span>{item.address}</span>
                 </div>
               )
             }
            </div>
            :<p>Please wait</p>
        }
      </div>
    )
  }
}

export default RestauranstList
