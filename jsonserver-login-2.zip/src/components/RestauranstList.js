import React, { Component } from 'react'

export class RestauranstList extends Component {
  render() {
    return (
      <div>
        <h1>Restauranst List</h1>
      </div>
    )
  }
}

export default RestauranstList
