import React, { Component } from 'react'

export class Footer extends Component {
  render() {
    return (
      <div>
        <center><h5>All Copyrights &copy; Reserved By Chandra - 2021</h5></center>
      </div>
    )
  }
}

export default Footer
