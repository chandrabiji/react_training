import React, { Component } from 'react'
import Footer from './Footer';
export class Home extends Component {
  render() {
    return (
      <div>
        <br /><br /><br /><br /><br /><br /><br />
        <h1>Welcome To <i>Ojas Resto </i>Restaurant Application</h1>
        <br /><br /><br /><br /><br /><br /><br />
        <Footer />
      </div>
    )
  }
}

export default Home
