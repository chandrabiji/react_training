import React, { Component } from 'react'

export class RestaurantDetail extends Component {
  render() {
    return (
      <div>
        <h1>Restaurant Detail</h1>
      </div>
    )
  }
}

export default RestaurantDetail
