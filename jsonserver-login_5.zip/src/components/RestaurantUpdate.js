import React, { Component } from 'react'

export class RestaurantUpdate extends Component {
  render() {
    return (
      <div>
        <h1>Restaurant Update</h1>
      </div>
    )
  }
}

export default RestaurantUpdate
